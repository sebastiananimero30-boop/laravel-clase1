<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenida</title>
</head>
<body>

    <h1>Bienvenido a mi primer proyecto Laravel</h1>
    <p>Desarrollado por: <strong>Tu Nombre</strong></p>

</body>
</html>
<?php /**PATH C:\Users\SENA\Desktop\mi-proyecto\resources\views/bienvenida.blade.php ENDPATH**/ ?>